(function(){
 'use strict';
 const initial={tone:6,hair:'afro',hc:'schwarz',eye:'braun',eyefx:'none',head:'none',headc:'schwarz',top:'none',hood:false,topc:'schwarz',bottom:'boxer',bottomc:'schwarz',hands:'gloves',glove:'schwarzgold',feet:'boots',feetc:'schwarz',coat:'none',aura:'none',scene:'holo',pose_profile:'cool',pose_card:'guard'};
 const query=new URLSearchParams(location.search),key='pr79-local-acceptance';
 if(query.has('reset'))sessionStorage.removeItem(key);
 let saved=JSON.parse(sessionStorage.getItem(key)||JSON.stringify(initial));
 const catalog=fetch('/__review/catalog.json').then(r=>r.json());
 const rpc=async(name,args)=>{
  if(query.has('slow'))await new Promise(r=>setTimeout(r,1500));
  if(name==='get_my_holo')return {data:{enabled:true,shop:true,display_name:'Lokales Testkonto',coins:0,config:structuredClone(saved),items:await catalog,bundles:[]},error:null};
  if(name==='save_my_holo'){saved=structuredClone(args.p_config);sessionStorage.setItem(key,JSON.stringify(saved));return {data:structuredClone(saved),error:null}}
  if(name.startsWith('buy_'))return {data:null,error:{message:'Lokaler Abnahmestand: alle Artikel sind Testbesitz; keine Käufe.'}};
  return {data:null,error:null};
 };
 const q={select(){return q},eq(){return q},order(){return q},limit(){return q},in(){return q},gte(){return q},lte(){return q},maybeSingle:async()=>({data:{role:'boxer',is_active:true,display_name:'Lokales Testkonto'},error:null}),then:r=>Promise.resolve({data:[],error:null}).then(r)};
 window.__takeoverMockClient={auth:{getSession:async()=>({data:{session:{access_token:'local-fixture'}}}),getUser:async()=>({data:{user:{id:'local-fixture'}},error:null}),onAuthStateChange:()=>({data:{subscription:{unsubscribe(){}}}})},from:()=>q,rpc};
 document.addEventListener('click',e=>{const a=e.target.closest('a');if(!a)return;const u=new URL(a.href,location.href);if(u.origin!==location.origin||!['/','/mein-boxer.html'].includes(u.pathname)){e.preventDefault();alert('Lokaler Teststand: nur Mein Boxer. Zur Testauswahl die Startadresse öffnen.')}} ,true);
})();
