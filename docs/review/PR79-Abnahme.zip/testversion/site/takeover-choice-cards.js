/* Takeover League · interactive horizontal select cards
   Enhances existing native selects only. Original values, names, IDs and listeners stay intact.
   Intentionally not loaded on the Coach dashboard. */
(function(){
 'use strict';
 const body=document.body;
 if(!body||!body.hasAttribute('data-tl-screen')||body.dataset.tlScreen==='coach')return;
 let hintSequence=0;
 function findTargets(root=document){
  const found=[];
  if(root.nodeType===1&&root.matches?.('form select,select[data-tl-choice]'))found.push(root);
  if(root.querySelectorAll)root.querySelectorAll('form select,select[data-tl-choice]').forEach(select=>found.push(select));
  return found;
 }
 const icons=[
  [/trainingslager|camp-tag/i,'🏕️'],[/pratzen|sandsack|schattenbox/i,'🥊'],[/seilspring|konditionszirkel/i,'⚡'],
  [/mobilität|regeneration/i,'🧘'],[/alternative ausdauer|\bradfahr|schwimm|rudern/i,'🚴'],[/trainingsassistenz/i,'🧑‍🏫'],
  [/sparring|duell|boxer|boxing/i,'🥊'],[/technik|ziel|challenge|target/i,'🎯'],
  [/kraft|strength/i,'💪'],[/sprint|intervall|tempo/i,'⚡'],[/jogg|lauf|km/i,'🏃'],
  [/wettkampf|arena|liga/i,'🏆'],[/exp|belohnung|punkte/i,'✨'],[/7 tage|woche/i,'⏱️'],
  [/14 tage|2 wochen/i,'🗓️'],[/30 tage|monat/i,'📅'],[/manuell|individuell|custom/i,'✍️'],
  [/training|einheit/i,'🥊'],[/coach/i,'🧑‍🏫']
 ];
 function symbol(label){
  for(const [pattern,emoji] of icons)if(pattern.test(label))return emoji;
  const parts=label.trim().split(/\s+/).filter(Boolean);
  return parts.length>1?(parts[0][0]+parts[1][0]).toLocaleUpperCase('de-CH'):(parts[0]||'•').slice(0,2).toLocaleUpperCase('de-CH');
 }
 function directLabel(select){
  if(select.getAttribute('aria-label'))return select.getAttribute('aria-label');
  const label=select.closest('label');
  if(label){
   const direct=Array.from(label.childNodes).filter(node=>node.nodeType===3).map(node=>node.textContent).join(' ').replace(/\s+/g,' ').trim();
   if(direct)return direct.replace(/[(:–-].*$/,'').trim()||direct;
  }
  const external=select.id&&document.querySelector('label[for="'+CSS.escape(select.id)+'"]');
  if(external)return external.textContent.trim();
  return select.name||select.id||'Auswahl';
 }
 function fireChange(select){
  select.dispatchEvent(new Event('input',{bubbles:true}));
  select.dispatchEvent(new Event('change',{bubbles:true}));
 }
 function enhance(select){
  if(select.dataset.tlChoiceEnhanced==='true')return;
  select.dataset.tlChoiceEnhanced='true';
  select.classList.add('tl-choice-native');
  const wrapper=document.createElement('div');wrapper.className='tl-choice-field';
  if(select.dataset.tlChoice)wrapper.dataset.choiceFor=select.dataset.tlChoice;
  const track=document.createElement('div');track.className='tl-choice-track';
  track.setAttribute('role','group');track.setAttribute('aria-label',directLabel(select));
  const note=document.createElement('p');note.className='tl-choice-note';note.setAttribute('aria-live','polite');
  const hintText=(select.dataset.tlChoiceHint||'').trim();
  if(hintText){
   const hint=document.createElement('p');hint.className='tl-choice-hint';hint.textContent=hintText;
   hint.id='tl-choice-hint-'+(++hintSequence);track.setAttribute('aria-describedby',hint.id);wrapper.append(hint);
  }
  const containingLabel=select.closest('label');
  if(containingLabel)containingLabel.insertAdjacentElement('afterend',wrapper);
  else select.insertAdjacentElement('afterend',wrapper);
  const tabs=document.createElement('div');tabs.className='tl-choice-tabs';tabs.setAttribute('role','tablist');
  tabs.setAttribute('aria-label',directLabel(select)+' · Bereiche');tabs.hidden=true;
  wrapper.append(tabs,track);
  if(select.multiple)wrapper.append(note);
  const label=directLabel(select);
  const FAVORITES='Häufig';
  let activeTab=null;
  // Nur eine geänderte Auswahl (Entwurf, letzte Art, Karte) darf den Bereich wechseln – ein Klick auf
  // eine Bereichs-Taste ändert die Auswahl nicht und muss deshalb stehen bleiben.
  let followedValue=select.value;
  const groupOf=option=>option.parentElement&&option.parentElement.tagName==='OPTGROUP'?option.parentElement.label:'';
  function favoriteValues(){return String(select.dataset.tlFavorites||'').split(',').map(x=>x.trim()).filter(Boolean)}
  function tabFor(value,groups,favorites){
   if(!value)return null;
   if(favorites.includes(value)&&activeTab===FAVORITES)return FAVORITES;
   const option=Array.from(select.options).find(o=>o.value===value);
   const group=option?groupOf(option):'';
   return groups.includes(group)?group:null;
  }
  function sync(){
   const selected=new Set(Array.from(select.selectedOptions).map(option=>option.value));
   track.querySelectorAll('button[data-value]').forEach(button=>{
    const active=selected.has(button.dataset.value);
    button.classList.toggle('is-selected',active);
    button.setAttribute('aria-pressed',String(active));
    const mark=button.querySelector('.tl-choice-check');
    if(mark)mark.textContent=active?'✓':(select.multiple?'+':'');
   });
   if(select.multiple){
    const count=selected.size;
    const valid=count>=3&&count<=8;
    note.textContent=valid?count+' Boxer ausgewählt.':count+' ausgewählt · Wähle 3–8 Boxer.';
    note.classList.toggle('is-valid',valid);
   }
   wrapper.classList.toggle('is-disabled',select.disabled);
   const valueChanged=select.value!==followedValue;followedValue=select.value;
   if(valueChanged&&wrapper.classList.contains('is-grouped')&&!select.multiple&&select.value&&!track.querySelector('button[data-value="'+CSS.escape(select.value)+'"]')){
    const groups=Array.from(tabs.querySelectorAll('[data-tab]')).map(b=>b.dataset.tab);
    const next=tabFor(select.value,groups,favoriteValues());
    if(next&&next!==activeTab){activeTab=next;render()}
   }
  }
  function render(){
   const options=Array.from(select.options).filter(option=>{
    if(option.disabled)return false;
    const label=(option.textContent||'').trim();
    const placeholder=/^(bitte wählen|bitte auswählen|auswählen|gegner wählen|ziel auswählen|boxer auswählen)$/i.test(label);
    return !(option.value===''&&(select.required||placeholder));
   });
   const groups=[...new Set(options.map(groupOf).filter(Boolean))];
   const grouped=!select.multiple&&groups.length>1;
   wrapper.classList.toggle('is-grouped',grouped);
   tabs.hidden=!grouped;tabs.replaceChildren();
   let shown=options;
   if(grouped){
    const favorites=favoriteValues().filter(v=>options.some(o=>o.value===v));
    const tabNames=(favorites.length?[FAVORITES]:[]).concat(groups);
    if(!activeTab||!tabNames.includes(activeTab))activeTab=tabFor(select.value,groups,favorites)||tabNames[0];
    if(select.value&&activeTab===FAVORITES&&!favorites.includes(select.value))activeTab=tabFor(select.value,groups,favorites)||activeTab;
    for(const name of tabNames){
     const tab=document.createElement('button');tab.type='button';tab.className='tl-choice-tab';tab.dataset.tab=name;
     tab.setAttribute('role','tab');tab.setAttribute('aria-selected',String(name===activeTab));tab.textContent=name;
     tab.classList.toggle('is-active',name===activeTab);
     tab.addEventListener('click',()=>{activeTab=name;render()});
     tabs.append(tab);
    }
    shown=activeTab===FAVORITES?favorites.map(v=>options.find(o=>o.value===v)):options.filter(o=>groupOf(o)===activeTab);
   }
   track.replaceChildren();
   if(!shown.length){
    const empty=document.createElement('span');empty.className='tl-choice-empty';
    empty.textContent='Auswahl wird geladen …';track.append(empty);
   }
   for(const option of shown){
    const button=document.createElement('button');button.type='button';button.className='tl-choice-card';
    button.dataset.value=option.value;button.disabled=select.disabled;
    button.setAttribute('aria-label',option.textContent.trim());
    button.setAttribute('aria-pressed',String(option.selected));
    const mark=document.createElement('span');mark.className='tl-choice-mark';mark.setAttribute('aria-hidden','true');mark.textContent=symbol(option.textContent);
    const copy=document.createElement('span');copy.className='tl-choice-copy';copy.textContent=option.textContent.trim();
    const check=document.createElement('span');check.className='tl-choice-check';check.setAttribute('aria-hidden','true');check.textContent=option.selected?'✓':(select.multiple?'+':'');
    const extra=[grouped&&activeTab===FAVORITES?groupOf(option):'',option.dataset.points?'+'+option.dataset.points+' Punkte':''].filter(Boolean).join(' · ');
    if(extra){const tag=document.createElement('small');tag.className='tl-choice-tag';tag.textContent=extra;copy.append(tag)}
    button.append(mark,copy,check);
    button.addEventListener('click',()=>{
     if(select.disabled||option.disabled)return;
     if(select.multiple)option.selected=!option.selected;
     else select.value=option.value;
     fireChange(select);sync();
    });
    track.append(button);
   }
   sync();
  }
  select.addEventListener('change',sync);
  select.addEventListener('reset',sync);
  const form=select.form;
  if(form)form.addEventListener('reset',()=>Promise.resolve().then(sync));
  const observer=new MutationObserver(render);
  observer.observe(select,{childList:true,subtree:true,attributes:true,attributeFilter:['disabled','label','value','data-tl-favorites']});
  render();
 }
 findTargets().forEach(enhance);
 const pageObserver=new MutationObserver(records=>{
  for(const record of records){
   for(const node of record.addedNodes){
    if(node.nodeType===1)findTargets(node).forEach(enhance);
   }
  }
 });
 pageObserver.observe(body,{childList:true,subtree:true});
})();
