'use strict';
const http=require('node:http'),fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const root=path.join(__dirname,'site'),lan=process.argv.includes('--lan'),slow=process.argv.includes('--slow');
const port=Number(process.env.PORT||4179);
const landing='<!doctype html><html lang="de"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>PR79 lokaler Test</title><style>body{max-width:700px;margin:30px auto;padding:20px;background:#101b2d;color:#ffe5a2;font:20px system-ui}a{color:#8fdcff;display:block;padding:18px}</style><h1>PR #79 · lokaler Test</h1><p>Nur Testdaten. Kein Login, keine echten Coins und keine Verbindung zu Supabase. Alle 58 Artikel sind Testbesitz. Speichern gilt nur in diesem Browser-Tab.</p><a href="/mein-boxer.html">Release A — normaler SVG-Editor</a><a href="/mein-boxer.html?art=modular">Release B — modularer Entwurf</a><a href="/mein-boxer.html?art=modular&slow=1">Entwurf mit verzögerter Testantwort</a><a href="/mein-boxer.html?reset=1">Testausstattung zurücksetzen</a><p>Galerie und Checkliste befinden sich eine Ebene über diesem Ordner. Keine persönliche oder produktive Freigabe.</p></html>';
const csp="default-src 'none'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; connect-src 'self'; media-src 'none'; object-src 'none'; frame-src 'none'; worker-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'";
const server=http.createServer((req,res)=>{
 res.setHeader('Content-Security-Policy',csp);res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');
 if(!['GET','HEAD'].includes(req.method)){res.writeHead(405);return res.end('Read-only local server')}
 let name;try{name=decodeURIComponent(new URL(req.url,'http://localhost').pathname)}catch{res.writeHead(400);return res.end()}
 const send=(body,type)=>{res.setHeader('Content-Type',type);res.end(req.method==='HEAD'?'':body)};
 if(name==='/')return send(landing,'text/html; charset=utf-8');
 if(name==='/__review/sdk.js')return send('export const createClient=()=>window.__takeoverMockClient;','text/javascript');
 if(name==='/__review/mock.js')return send(fs.readFileSync(path.join(__dirname,'mock.js')),'text/javascript');
 if(name==='/__review/catalog.json')return send(fs.readFileSync(path.join(__dirname,'catalog.json')),'application/json');
 if(name==='/news.json')return send('{"entries":[]}','application/json');
 if(name.endsWith('.html')&&name!=='/mein-boxer.html')return send(landing,'text/html; charset=utf-8');
 const file=path.resolve(root,'.'+name);
 if(!file.startsWith(root+path.sep)||!['.html','.js','.css','.png','.svg','.woff','.webmanifest','.json'].includes(path.extname(file))){res.writeHead(403);return res.end()}
 fs.readFile(file,(error,data)=>{if(error){res.writeHead(404);return res.end()}
  const ext=path.extname(file);
  if(ext==='.js'||ext==='.html')data=data.toString().replaceAll('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm','/__review/sdk.js');
  if(name==='/mein-boxer.html')data=data.replace('</head>','<script src="/__review/mock.js"></script></head>');
  const deliver=()=>send(data,({'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml','.woff':'font/woff','.json':'application/json','.webmanifest':'application/manifest+json'})[ext]);
  if(slow&&ext==='.png')setTimeout(deliver,1200);else deliver();
 });
});
server.listen(port,lan?'0.0.0.0':'127.0.0.1',()=>{console.log('PR79, nur lokale Testdaten. Stoppen: Strg+C.');console.log('PC: http://127.0.0.1:'+port);if(lan)for(const list of Object.values(os.networkInterfaces()))for(const a of list||[])if(a.family==='IPv4'&&!a.internal)console.log('Smartphone im selben privaten WLAN: http://'+a.address+':'+port);console.log('Keine externen Dienste erlaubt; kein Proxy, keine schreibenden HTTP-Endpunkte.');});
